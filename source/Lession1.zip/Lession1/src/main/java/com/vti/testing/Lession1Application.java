package com.vti.testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lession1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lession1Application.class, args);
	}

}
