package com.vti.testing.entity;

public enum Type {
    Dev, Test, ScrumMaster, PM
}
